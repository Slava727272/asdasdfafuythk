import time
from binance.client import Client
import websocket
import telebot
import threading
import datetime
import json
import sys
import csv
import emoji

API_KEY = '6055267076:AAFp8a11Sucx4N3N39SZ5Hyot0SsuNT9pfg'
bot = telebot.TeleBot(API_KEY)
chat_id = '-854914417'
coin_list = []
client = Client(
            api_key='Ts3dktxOQc9IYg65iILxoO42Zu7xRdESkE2MdqqoD4XPwvghlSnoYaf82Tg5IMlG',
            api_secret='yYQ7HYnle8RHY3VReyFav02boRfspFXAKPMHXmcSRbZFAieJlexIxSDZFvrvHmEG'
    )


# Добавить проверку активных позиций
try:
    with open('Position_history.csv', 'r', newline='') as file:
        reader = csv.reader(file, delimiter=';')
        data = list(reader)
        last_symbol = data[-1][0]

        # Просмотр активных позиций
    for info_position in client.futures_position_information():
        if info_position['symbol'] == last_symbol and float(info_position['positionAmt']) != 0:
            print(f'Позиция {info_position} - еще открыта')
            sys.exit()
        # Отправляем нотификацию в телеге о закрытии позиции и записываем данные в csv файл
        elif info_position['symbol'] == last_symbol and float(info_position['positionAmt']) == 0 and data[-1][8] == 'Entrance':
            current_datetime = datetime.datetime.now()
            formatted_datetime = current_datetime.strftime("%d.%m.%Y  |  %H:%M:%S ")
            data_csv = current_datetime.strftime("%H:%M:%S %d.%m.%Y")
            csv_list = [data[-1][0], data[-1][7], ' - ', data[-1][3], data[-1][4], data[-1][5], data[-1][6], data[-1][7], 'Exit', data_csv]
            with open('Position_history.csv', 'a', newline='') as file:
                writer = csv.writer(file, delimiter=';')
                writer.writerow(csv_list)

            close_position = f'*Позиция {data[-1][0]} закрыта* ✅\n\n*Цена выхода:* {data[-1][7]} $\n\n*Время закрытия позиции:* {formatted_datetime}'
            bot.send_message(chat_id, close_position, parse_mode='Markdown')



# Создаем файл с шапкой, если его нету в папке
except FileNotFoundError:
    with open('Position_history.csv', 'w', newline='') as file:
        writer = csv.writer(file, delimiter=';')
        writer.writerow(['Symbol', 'Last_Price', 'New_Price', 'High_Price', 'Low_Price', 'Percent', 'Count_Money', 'Exit_Price', 'Status', 'Time'])

time.sleep(1)
all_money_exchenge = client.futures_ticker() # Получаем список всех монет на фьючах с бинанса
# Открываем список и достаем монеты, которые интересны нам: Цена > 0.09$ и процент роста за день > 8% в паре с UDST
for open_position in all_money_exchenge:
    if 'USDT' in open_position.get('symbol') and float(open_position.get('priceChangePercent')) > 8 and float(open_position.get('lastPrice')) > 0.09:
        #print(open_position)
        symbol = open_position['symbol'] # Пара
        priceChangePercent = float(open_position['priceChangePercent']) # Процент роста за день
        highPrice = float(open_position['highPrice'])  # Максимальная цена моенты за день
        lowPrice = float(open_position['lowPrice'])  # Минимальная цена монеты за день
        lastPrice = float(open_position['lastPrice'])  # Последняя цена монеты
        tic = len(str(highPrice).split('.')[1])  # Кол-во чисел после запятой, чтобы влететь ровно в позицию
        my_proc = (3.72 * lowPrice) / 100  # Дельта от минимальной цены
        new_price = round(highPrice + my_proc, tic)  # Цена входа в позицию
        print(f'Пара - {symbol}\nПроцент роста за день - {priceChangePercent} %\nМаксимальная цена моенты за день - {highPrice} $\nМинимальная цена монеты за день - {lowPrice} $\nТекущая цена монеты - {lastPrice} $\nЦена входа в позицию - {highPrice} $\n')
        activ_list = [symbol, lastPrice, new_price, highPrice, lowPrice, priceChangePercent, tic]
        coin_list.append(activ_list)


# Выбираем линк для подключения к вебсокету в зависимости от числа монет подходящих под условие
if len(coin_list) == 0:
    print('На данный момент монет с таким ростом нету')
    sys.exit()

elif len(coin_list) == 1:
    href = f'wss://fstream.binance.com/ws/{str(coin_list[0][0]).lower()}@markPrice'
    print(href)

elif len(coin_list) > 1:
    symbol_list = []
    for open_coin in coin_list:
        symbol_list.append(str(open_coin[0]).lower() + '@markPrice/')
    coin_string = ''.join(symbol_list)[:-1]
    href = 'wss://fstream.binance.com/stream?streams=' + coin_string
    print(href)


# Чекаем через вебсокет данные в реальном времени пока не выстрелит наше условие
win_list = []
def on_message(ws, message):
    json_data = json.loads(message)
    if len(coin_list) == 1:
        data = json_data['s']
        price = json_data['p']
    elif len(coin_list) > 1:
        data = json_data['data']['s']
        price = json_data['data']['p']
    for open_coin_list in coin_list:
        if open_coin_list[0] == data:  # !!!!!!!!!!!!!!!!!!!!!!!!!!
            if float(open_coin_list[3]) < float(price):  # Если выполняется это условие, значит текущее значение монеты преодолело максимум за 24ч.
                win_list.append(open_coin_list)
                ws.close()


def on_close(ws):
    print("Сlosed")

ws = websocket.WebSocketApp(href, on_message=on_message, on_close=on_close)
ws.run_forever()


# Работаем с полученной монетой из вебсокета
if win_list[0][2] <= 60:  # Если монета дешевле нашей позиции высчитываем ее количество для позиции
    quantity = int(5 * 10 / win_list[0][2])
elif win_list[0][2] > 60:
    quantity = float(round(5 * 10 / win_list[0][2]), 2)

#Установка плеча для символа
client.futures_change_leverage(
        symbol=win_list[0][0],
        leverage=10
    )

# Встаем в позицию
position_size = round(quantity * win_list[0][2], 2)
order = client.futures_create_order(
                        symbol=win_list[0][0],
                        side=Client.SIDE_SELL,  # Открываем шорт
                        type=Client.ORDER_TYPE_MARKET,  # Заходим по маректу
                        quantity=quantity
                    )




#Установка ордера на продажу шорт позиции
last_price = win_list[0][3]  # Цена входа в позицию  !!!!!!!!!!!!!!!!!!!!!!!!!!
print(last_price)
end_position = round(last_price - last_price/120, win_list[0][6])  #Цена ВЫХОДА из позиции при прибыли 10% (учитывая плечо 10)
print(end_position)
exit_order = client.futures_create_order(symbol=win_list[0][0],
                                         side=client.SIDE_BUY,
                                         type=client.ORDER_TYPE_LIMIT,
                                         timeInForce=client.TIME_IN_FORCE_GTC,
                                         quantity=quantity,
                                         price=end_position
                                        )


# Записываем в CSV файл инфу о сделке
current_datetime = datetime.datetime.now()
formatted_datetime = current_datetime.strftime("%d.%m.%Y  |  %H:%M:%S ")
data_csv = current_datetime.strftime("%H:%M:%S %d.%m.%Y")
csv_list = [win_list[0][0], win_list[0][1], win_list[0][2], win_list[0][3], win_list[0][4], win_list[0][5], quantity, end_position, 'Entrance', data_csv]
with open('Position_history.csv', 'a', newline='') as file:
    writer = csv.writer(file, delimiter=';')
    writer.writerow(csv_list)


# Отправляем нотификацию в телеге об открытии позиции
best_result = f'*Открываю новую позицию*{emoji.emojize("❗")}\n\n*Пара:* {win_list[0][0]}\n*Рост за день:* {win_list[0][5]} %\n*Позиция:* Short\n*Цена входа:* {win_list[0][2]} $\n*Размер позиции:* {position_size} $\n\n*Время захода в позицию:* {formatted_datetime}'
bot.send_message(chat_id, best_result, parse_mode='Markdown')