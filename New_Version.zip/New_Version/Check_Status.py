# pip install psutil
import time
import psutil
import subprocess
from datetime import datetime, timedelta


while True:
    i = 0  # Флаг на активный процесс
    max_duration_minutes = 45  # Время перезапуска торгового скрипта


    for process in psutil.process_iter(attrs=['pid', 'name', 'cmdline']):
        if 'python' in str(process.name):
            pid = int(process.pid)
            processes = psutil.Process(pid)
            cmdline = processes.cmdline()
            if 'Futures_Short_Bot.py' in cmdline[1]:
                print(processes)
                processes_list = str(processes).split("'")
                started = processes_list[5]
                target_time = datetime.strptime(started, '%H:%M:%S').time()
                # Чтобы чекер не слетал в 00, будем ребутать его принудилтельно
                time_time = datetime.now()
                zero_time = time_time.strftime('%H')
                if str(zero_time) == '00':
                    process_obj = psutil.Process(process.info['pid'])
                    process_obj.terminate()
                    break
                current_time = datetime.now().time()
                i += 1

                if current_time > target_time:
                    time_since_start = datetime.combine(datetime.today(), current_time) - datetime.combine(datetime.today(), target_time)
                    print(time_since_start)
                    if time_since_start > timedelta(minutes=max_duration_minutes): # Гасим скрипт если он работает больше 50 минут
                        process_obj = psutil.Process(process.info['pid'])
                        process_obj.terminate()
                        print('Скрипт выключен')
                        script_path = 'Futures_Short_Bot.py'
                        subprocess.Popen(['python', script_path], creationflags=subprocess.DETACHED_PROCESS)
                        print('Script запущен')
                    else:
                        print(f'Время для перезапуска еще не пришло.\nВремя запуска - {target_time}')

    # Если скрипт не робит, перезапускаем его
    if i != 1:
        print('Script не запущен')
        script_path = r'Futures_Short_Bot.py'
        subprocess.Popen(['python', script_path], creationflags=subprocess.DETACHED_PROCESS)
        print('Script запущен')

    current_time = datetime.now().time()
    print(f'Ждем-с. Текущее время - {current_time}')
    time.sleep(600)

